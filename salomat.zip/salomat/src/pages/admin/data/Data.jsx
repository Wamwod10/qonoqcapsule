import React, { useEffect, useState } from "react";
import "./data.scss";

const API = "http://localhost:5000/api/bookings";

const branches = [
  { id: "airport", name: "Tashkent Airport" },
  { id: "city", name: "City Center" },
  { id: "north", name: "North Branch" },
];

const Data = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    branch: "airport",
    capsuleType: "family",
    date: "",
    time: "",
    duration: "4",
  });

  const loadBookings = async () => {
    try {
      setLoading(true);
      const res = await fetch(API);
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      alert("Backend error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const addBooking = async () => {
    if (!form.date || !form.time) return alert("Date & time required");

    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    setForm({ ...form, date: "", time: "" });
    loadBookings();
  };

  const deleteBooking = async (id) => {
    if (!confirm("Delete?")) return;
    await fetch(`${API}/${id}`, { method: "DELETE" });
    loadBookings();
  };

  return (
    <div className="admin">
      <h1>Admin — Capsule Bookings</h1>

      <div className="admin__form">
        <select
          value={form.branch}
          onChange={(e) => setForm({ ...form, branch: e.target.value })}
        >
          {branches.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>

        <select
          value={form.capsuleType}
          onChange={(e) => setForm({ ...form, capsuleType: e.target.value })}
        >
          <option value="family">Family</option>
          <option value="standard">Standard</option>
        </select>

        <input
          type="date"
          value={form.date}
          onChange={(e) => setForm({ ...form, date: e.target.value })}
        />

        <input
          type="time"
          value={form.time}
          onChange={(e) => setForm({ ...form, time: e.target.value })}
        />

        <select
          value={form.duration}
          onChange={(e) => setForm({ ...form, duration: e.target.value })}
        >
          <option value="4">4h</option>
          <option value="6">6h</option>
          <option value="10">10h</option>
        </select>

        <button onClick={addBooking}>Add</button>
      </div>

      <div className="admin__list">
        {loading && <p>Loading...</p>}

        {bookings.map((b) => (
          <div key={b.id} className="admin__card">
            <b>{b.branch}</b> | {b.capsuleType} | {b.date} {b.time} | {b.duration}h
            <button onClick={() => deleteBooking(b.id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Data;
