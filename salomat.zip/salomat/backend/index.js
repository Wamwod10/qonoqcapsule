const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const crypto = require("crypto");
const axios = require("axios");

dotenv.config();

const app = express();
const PORT = 5000;

app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json());

/* ================= DB ================= */

const DB_PATH = path.join(__dirname, "bookings.db");

const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) console.error("DB ERROR:", err.message);
    else console.log("✅ SQLite connected");
});

/* ===== CREATE TABLE ===== */

db.run(`
  CREATE TABLE IF NOT EXISTS bookings (
    id TEXT PRIMARY KEY,
    branch TEXT,
    capsuleType TEXT,
    date TEXT,
    time TEXT,
    duration TEXT,
    createdAt TEXT
  )
`);

/* ================= TEST ================= */

app.get("/", (req, res) => {
    res.send("Backend is working ✅");
});

/* ================= BOOKINGS ================= */

// GET ALL
app.get("/api/bookings", (req, res) => {
    db.all("SELECT * FROM bookings ORDER BY date, time", [], (err, rows) => {
        if (err) {
            console.error("DB GET ERROR:", err);
            return res.status(500).json({ error: "DB error" });
        }
        res.json(rows);
    });
});

// ADD
app.post("/api/bookings", (req, res) => {
    const { branch, capsuleType, date, time, duration } = req.body;

    if (!branch || !date || !time || !duration) {
        return res.status(400).json({ error: "Missing fields" });
    }

    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();

    db.run(
        `INSERT INTO bookings (id, branch, capsuleType, date, time, duration, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?)`, [id, branch, capsuleType || "family", date, time, duration, createdAt],
        function(err) {
            if (err) {
                console.error("DB INSERT ERROR:", err);
                return res.status(500).json({ error: "Insert failed" });
            }

            res.json({
                success: true,
                booking: { id, branch, capsuleType, date, time, duration, createdAt },
            });
        }
    );
});

// DELETE
app.delete("/api/bookings/:id", (req, res) => {
    const { id } = req.params;

    db.run("DELETE FROM bookings WHERE id = ?", [id], function(err) {
        if (err) {
            console.error("DB DELETE ERROR:", err);
            return res.status(500).json({ error: "Delete failed" });
        }

        res.json({ success: true });
    });
});

/* ================= AVAILABILITY CHECK (NEW) ================= */

function toMinutes(t) {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
}

app.post("/api/check-availability", (req, res) => {
    const { branch, capsuleType, date, time, duration } = req.body;

    if (!branch || !capsuleType || !date || !time || !duration) {
        return res.status(400).json({ error: "Missing fields" });
    }

    const roomLimit = capsuleType === "family" ? 2 : 4;

    const reqStart = toMinutes(time);
    const reqEnd = reqStart + Number(duration) * 60;

    db.all(
        `SELECT * FROM bookings WHERE branch=? AND capsuleType=? AND date=?`, [branch, capsuleType, date],
        (err, rows) => {
            if (err) {
                console.error("AVAIL ERROR:", err);
                return res.status(500).json({ error: "DB error" });
            }

            const overlaps = rows.filter((b) => {
                const s = toMinutes(b.time);
                const e = s + Number(b.duration) * 60;
                return reqStart < e && reqEnd > s;
            });

            if (overlaps.length < roomLimit) {
                return res.json({ available: true });
            }

            const nextFree = overlaps
                .map((b) => toMinutes(b.time) + Number(b.duration) * 60)
                .sort((a, b) => a - b)[0];

            const hh = String(Math.floor(nextFree / 60)).padStart(2, "0");
            const mm = String(nextFree % 60).padStart(2, "0");

            res.json({
                available: false,
                nextTime: `${hh}:${mm}`,
            });
        }
    );
});

/* ================= PAYMENT (OCTO) ================= */

app.post("/create-payment", async(req, res) => {
    try {
        const { amount } = req.body;

        if (!amount) {
            return res.status(400).json({ error: "Amount is required" });
        }

        const response = await axios.post(
            "https://api.octo.uz/payment/create", {
                shop_id: process.env.OCTO_SHOP_ID,
                amount: amount,
                currency: "UZS",
                description: "Qonoq Capsule Booking",
                return_url: "http://localhost:5173/mybooking",
            }, {
                headers: {
                    Authorization: `Bearer ${process.env.OCTO_SECRET}`,
                    "Content-Type": "application/json",
                },
            }
        );

        const paymentUrl =
            response.data && response.data.payment_url ?
            response.data.payment_url :
            null;

        res.json({ paymentUrl });
    } catch (err) {
        console.error(
            "OCTO ERROR:",
            err.response ? err.response.data : err.message
        );
        res.status(500).json({ error: "Payment create failed" });
    }
});

/* ================= START ================= */

app.listen(PORT, () => {
    console.log(`✅ Backend running on http://localhost:${PORT}`);
});